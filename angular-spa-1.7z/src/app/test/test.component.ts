import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-test',
  standalone: true,
  imports: [RouterModule, CommonModule, FormsModule],
  template: `
    <div>
      <p>Regression Test</p>
      <nav>
      <label for="environment">NPE:</label>
        <select id="environment" [(ngModel)]="environment">
          <option *ngFor="let env of environments" [value]="env">{{ env }}</option>
        </select>
        <a href="#" (click)="prepareData()">Prepare Data</a>
        <a href="#" (click)="runTest()">Run Test</a>
        <a href="#" (click)="getReport()">Get Report</a>
      </nav>
      <br/>
      <div *ngIf="apiResponse">
        <pre>{{ apiResponse | json }}</pre>
      </div>
   </div>
  `,
  styles: [
    `
     h1 {
        font-family: Arial, sans-serif;
        color: #1976d2;
      }

      h3 {
        font-family: Arial, sans-serif;
        color: #d2192c;
      }

      p {
        font-family: Arial, sans-serif;
        color: red;
      }
      pre {
        background-color: #f5f5f5;
        padding: 10px;
        border-radius: 5px;
      }
      div {
        margin-bottom: 5px;
      }

      label {
        margin-right: 10px;
      }
      select,
      input {
        margin-right: 10px;
      }
      table {
        font-size: 16px;
        width: 100%;
        border-collapse: collapse;
      }
      table,
      th,
      td {
        border: 1px solid #ccc;
      }
      th,
      td {
        padding: 8px;
        text-align: left;
      }
    `,
  ],
  styleUrls: ['./test.component.css'],
  providers: [DatePipe]
})
export class TestComponent {
  apiResponse: any;
  environments = ['QA01', 'QA02', 'QA04'];
  fileTypes = ['JSON', 'Excel'];
  amdocsApis = ['BR Creation', 'Retrieve BR Content', 'Catalogue Activity', 'Release Queue - Publish'];
  environment = this.environments[0];

  constructor(private http: HttpClient, private datePipe: DatePipe) { }

  ngOnInit() {
    this.http.get('http://localhost:8080/api/test').subscribe((response) => {
      this.apiResponse = response;
    });
  }

  prepareData() {
    console.log('Prepare data...');
    const apiUrl = `http://localhost:8080/api/test/preparedata?env=${this.environment}`;
    console.log("call api:" + apiUrl);
    this.http.get<any[]>(apiUrl).subscribe((response) => {
      this.apiResponse = response;
    });
  }

  runTest() {
    console.log('Run test...');
    const apiUrl = `http://localhost:8080/api/test/runtest?env=${this.environment}`;
    console.log("call api:" + apiUrl);
    this.http.get<any[]>(apiUrl).subscribe((response) => {
      this.apiResponse = response;
    });
  }
  getReport() {
    console.log('Get Report...');
    const apiUrl = `http://localhost:8080/api/test/getreport?env=${this.environment}`;
    console.log("call api:" + apiUrl);
    this.http.get<any[]>(apiUrl).subscribe((response) => {
      this.apiResponse = response;
    });
  }

}
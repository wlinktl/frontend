import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BRListComponent } from './br-list/br-list.component';
import { BRDetailComponent } from './br-detail/br-detail.component';
import { ExportComponent } from './export/export.component';

const routes: Routes = [
  { path: '', redirectTo: '/br-list', pathMatch: 'full' },
  { path: 'br-list', component: BRListComponent },
  { path: 'br-detail/:brId', component: BRDetailComponent },
  { path: 'export', component: ExportComponent },
  { path: '**', redirectTo: '/br-list' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BRListComponent } from './br-list/br-list.component';
import { BRDetailComponent } from './br-detail/br-detail.component';
import { ExportComponent } from './export/export.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    BRDetailComponent
  ],
  imports: [
    BRListComponent,
    ExportComponent,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '/br-create',
    loadComponent: () =>
      import('./br-create/br-create.component').then((m) => m.BRCreateComponent),
  },
  {
     path: '/br-detail/:id',
      loadComponent: () =>
        import('./br-detail/br-detail.component').then((m) => m.BRDetailComponent),
  },
  // Add other routes here
  { path: '', redirectTo: '/', pathMatch: 'full' },
];

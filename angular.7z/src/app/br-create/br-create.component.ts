import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-export',
  standalone: true,
  imports: [RouterModule, CommonModule, FormsModule],
  template: `
    <div>
      <h3>PAMS</h3>
      <nav>
        <a routerLink="/transfer">Transfer</a>
        <a routerLink="/export">Export</a>
      </nav>
      <hr/>
      <div>
        <label for="sourceEnvironment">Source NPE:</label>
        <select id="sourceEnvironment" [(ngModel)]="selectedSourceEnvironment">
          <option *ngFor="let env of environments" [value]="env">{{ env }}</option>
        </select>
  
        <br/><br/>
        <label for="fromDate">From Date:</label>
        <input type="date" id="fromDate" [(ngModel)]="fromDate" />
        <label for="toDate">To Date:</label>
        <input type="date" id="toDate" [(ngModel)]="toDate" />
        
        <button (click)="retrieve()">Retrieve</button>

        <br/><br/>
        <label for="targetEnvironment">Target NPE:</label>
        <select id="targetEnvironment" [(ngModel)]="selectedTargetEnvironment">
          <option *ngFor="let env of environments" [value]="env">{{ env }}</option>
        </select>
        <button (click)="transfer()">Transfer</button>

      </div>
      <!--div>
        <label for="fileType">File Type:</label>
        <select id="fileType" [(ngModel)]="selectedFileType">
          <option *ngFor="let type of fileTypes" [value]="type">{{ type }}</option>
        </select>
      </div-->

      <!--div>
        <label for="amdocsApi">Amdocs API:</label>
        <select id="amdocsApi" [(ngModel)]="selectedAmdocsApi">
          <option *ngFor="let api of amdocsApis" [value]="api">{{ api }}</option>
        </select>
      </div-->
 
      <!-- BR List Content Panel -->
      <div *ngIf="brList && brList.length">
        <h5>BR Lists</h5>
        <table>
          <thead>
            <tr>
              <th>Select</th>
              <th>BR ID</th>
              <th>Offer</th>
              <th>Description</th>
              <th>Created Date</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let br of brList">
              <td><input type="checkbox" [(ngModel)]="br.isSelected" /></td>
              <!--td>{{ br.brId }}</td-->
              <td><a [routerLink]="['/br-detail', br.brId]">{{ br.brId }}</a></td>
              <td>{{ br.offer }}</td>
              <td>{{ br.description }}</td>
              <td>{{ br.createdDate }}</td>
              <td>{{ br.amount }}</td>
            </tr>
          </tbody>
        </table>
        
        <br/>

      </div>

      <!--a href="#" (click)="downloadExcel($event)">Download Excel file</a-->

      <!--div *ngIf="apiResponse">
        <h4>RetrieveBR response:</h4>
        <pre>{{ apiResponse | json }}</pre>
      </div-->

      <br/>
    
    </div>
  `,
  styles: [
    `
      h1 {
        font-family: Arial, sans-serif;
        color: #1976d2;
      }
      p {
        font-family: Arial, sans-serif;
        color: #333;
      }
      pre {
        background-color: #f5f5f5;
        padding: 10px;
        border-radius: 5px;
      }
      div {
        margin-bottom: 10px;
      }
      label {
        margin-right: 10px;
      }
      select,
      input {
        margin-right: 10px;
      }
      table {
        font-size: 16px;
        width: 100%;
        border-collapse: collapse;
      }
      table,
      th,
      td {
        border: 1px solid #ccc;
      }
      th,
      td {
        padding: 8px;
        text-align: left;
      }
    `,
  ],
  styleUrls: ['./br-create.component.css'],
  providers: [DatePipe]
})
export class BRCreateComponent {
  apiResponse: any;
  environments = ['QA01', 'QA02', 'QA04'];
  fileTypes = ['JSON', 'CSV'];
  amdocsApis = ['BR Creation', 'Retrieve BR Content', 'Catalogue Activity', 'Release Queue - Publish'];
  selectedSourceEnvironment = this.environments[0];
  selectedTargetEnvironment = this.environments[0];
  selectedFileType = this.fileTypes[0];
  selectedAmdocsApi = this.amdocsApis[0];
  fromDate: string = '';
  toDate: string = '';
  brList: any[] = [];

  constructor(private http: HttpClient, private datePipe: DatePipe) { }

  ngOnInit() {
    this.http.get('http://localhost:8080/api/retrieveBR_1').subscribe((response) => {
      this.apiResponse = response;
    });
  }

  downloadExcel(event: Event) {
    event.preventDefault();
    this.http
      .get('http://localhost:8080/api/retrieveBR_2', { responseType: 'blob' })
      .subscribe((blob) => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'report.xlsx';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      });
  }

  retrieve() {
    console.log('Submit button clicked');
    // existing submit logic
    const params = {
      sourceEnvironment: this.selectedSourceEnvironment,
      targetEnvironment: this.selectedTargetEnvironment,
      fileType: this.selectedFileType,
      fromDate: this.fromDate,
      toDate: this.toDate,
      amdocsApi: this.selectedAmdocsApi,
    };
    const fromDate = this.datePipe.transform(this.fromDate, 'yyyy-MM-dd'); // Ensure these properties are defined and populated
    const toDate = this.datePipe.transform(this.toDate, 'yyyy-MM-dd');

    const apiUrl = `http://localhost:8080/api/getBRList?fromDate=${fromDate}&toDate=${toDate}&envId=${this.selectedSourceEnvironment}`;
    console.log("call api:" + apiUrl);
    this.http.get<any[]>(apiUrl).subscribe((response) => {
      this.brList = response;
    });

  }

  transfer() {
    console.log('Transfer button clicked');
    const selectedBRs = this.brList.filter((br) => br.isSelected);

    const params = {
      sourceEnvId: this.selectedSourceEnvironment,
      targetEnvId: this.selectedTargetEnvironment,
      brList: selectedBRs
    };

    const apiUrl = `http://localhost:8080/api/transferBRList?sourceEnvId=${this.selectedSourceEnvironment}&targetEnvId=${this.selectedTargetEnvironment}`;
    this.http.get<any[]>(apiUrl).subscribe((response) => {
      this.brList = response;
    });
  }
}
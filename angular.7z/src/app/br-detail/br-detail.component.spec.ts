import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BRDetailComponent } from './br-detail.component';

describe('BRDetailComponent', () => {
  let component: BDetailComponent;
  let fixture: ComponentFixture<BRDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BRDetailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BRDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

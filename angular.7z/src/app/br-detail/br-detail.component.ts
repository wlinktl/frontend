import { Component, OnInit } from '@angular/core'
import { ActivatedRoute } from '@angular/router'
import { HttpClient } from '@angular/common/http'

@Component({
  selector: 'app-br-detail',
  templateUrl: './br-detail.component.html',
  styleUrls: ['./br-detail.component.css'],
})
export class BRDetailComponent implements OnInit {
  brId!: string
  br: any
  offerList: any[] = []

  constructor(private route: ActivatedRoute, private http: HttpClient) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('brId')
    console.log("id", id)
    if (id !== null) {
      this.brId = id
      console.log("this.brId", this.brId)
      this.http.get<any[]>('/assets/brs.json').subscribe((brs) => {
        this.br = brs.find((br) => br.BRID === this.brId)
        if (this.br) {
          this.offerList = this.br.offer
        } else {
          console.error(`BR with BRID ${this.brId} not found`)
        }
        console.log(this.brId, this.br)
      })
    }
  }
}

import { Component, OnInit } from '@angular/core';
import Chart from 'chart.js/auto';

@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.css']
})
export class PieChartComponent implements OnInit {
  public chart: any;

  ngOnInit(): void {
    this.createChart();
  }

  createChart() {
    this.chart = new Chart('MyChart', {
      type: 'pie', // Type of chart
      data: {
        labels: ['Passed', 'Failed', 'Skipped'], // Labels for the chart
        datasets: [{
          label: 'Test Results',
          data: [70, 20, 10], // Data for the chart
          backgroundColor: ['#5AA454', '#A10A28', '#C9C9C9'] // Colors for the chart
        }]
      },
      options: {
        responsive: true, // Make the chart responsive
        plugins: {
          legend: {
            position: 'top', // Position of the legend
          },
          title: {
            display: true,
            text: 'Test Results' // Title of the chart
          }
        }
      }
    });
  }
}
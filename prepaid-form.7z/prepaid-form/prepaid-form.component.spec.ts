import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrepaidFormComponent } from './prepaid-form.component';

describe('PrepaidFormComponent', () => {
  let component: PrepaidFormComponent;
  let fixture: ComponentFixture<PrepaidFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PrepaidFormComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrepaidFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

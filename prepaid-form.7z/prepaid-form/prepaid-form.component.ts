import { Component } from '@angular/core';

@Component({
  selector: 'prepaid-form',
  standalone: true,
  imports: [],
  templateUrl: './prepaid-form.component.html',
  styleUrl: './prepaid-form.component.css'
})
export class PrepaidFormComponent {

}

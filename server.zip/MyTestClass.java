package com.example.demo.tests;

import org.testng.annotations.Test;

public class MyTestClass {

    @Test
    public void testMethod() {
        System.out.println("Running TestNG test method!");
    }
}
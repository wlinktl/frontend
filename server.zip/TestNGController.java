package com.example.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.testng.TestNG;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/testng")
public class TestNGController {

    @GetMapping("/run")
    public String runTestNGSuite() {
        try {
            // Path to the external JAR file
            String jarPath = "path/to/test1.jar"; // Replace with the actual path to your JAR file

            // Load the JAR file dynamically
            File jarFile = new File(jarPath);
            URL jarUrl = jarFile.toURI().toURL();
            URLClassLoader classLoader = new URLClassLoader(new URL[]{jarUrl}, Thread.currentThread().getContextClassLoader());

            // Set the class loader for the current thread
            Thread.currentThread().setContextClassLoader(classLoader);

            // Create an instance of TestNG
            TestNG testNG = new TestNG();

            // Set the test suite XML file (assuming it's inside the JAR)
            List<String> suites = new ArrayList<>();
            suites.add("src/test/suites/test_1.xml"); // Path to the test suite XML file inside the JAR
            testNG.setTestSuites(suites);

            // Run the tests
            testNG.run();

            return "TestNG suite executed successfully!";
        } catch (Exception e) {
            e.printStackTrace();
            return "Failed to execute TestNG suite: " + e.getMessage();
        }
    }
}
package com.r.pams;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PAMSApplication {

	public static void main(String[] args) {
		SpringApplication.run(PAMSApplication.class, args);
	}

}

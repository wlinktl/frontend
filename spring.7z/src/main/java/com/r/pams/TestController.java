package com.r.pams;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/test")
public class TestController {

        @GetMapping("/preparedata")
        public String preparedata(@RequestParam("env") String env) {
                System.out.println("Prepare data for environment " + env);
                try {
                        ObjectMapper objectMapper = new ObjectMapper();
                        Map<String, String> response = new HashMap<>();
                        response.put("test", "Prepare data for environment " + env);
                        return objectMapper.writeValueAsString(response);

                } catch (Exception e) {
                        return "{\"error\":\"Failed to prepare data\"}";
                }
        }

        @GetMapping("/runtest")
        public String runtest(@RequestParam("env") String env) {
                System.out.println("Run test for environment " + env);
                try {
                        ObjectMapper objectMapper = new ObjectMapper();
                        Map<String, String> response = new HashMap<>();
                        response.put("test", "Run test for environment " + env);
                        return objectMapper.writeValueAsString(response);
                } catch (Exception e) {
                        return "{\"error\":\"Failed to run test\"}";
                }
        }

        @GetMapping("/getreport")
        public String getreport(@RequestParam("env") String env) {
                System.out.println("Get report for environment " + env);
                try {
                        ObjectMapper objectMapper = new ObjectMapper();
                        Map<String, String> response = new HashMap<>();
                        response.put("test", "Get report for environment " + env);
                        return objectMapper.writeValueAsString(response);
                } catch (Exception e) {
                        return "{\"error\":\"Failed to get report\"}";
                }
        }

}

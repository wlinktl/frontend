package com.r.pams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PAMSApplicationTests {

	@Test
	void contextLoads() {
	}

}
